package org.game;

import org.graphics.Renderer;
import org.object.BadGuy;
import org.object.Platform;
import org.object.Player;
import org.world.World;

public class Game {
    public static void main(String[] args) {
        Renderer.init();
        World.currentWorld = new World();
        World.currentWorld.addSprite(new Platform(200,200,300,200));
        World.currentWorld.addSprite(new Platform(150,150,30,50));
        //World.currentWorld.addSprite(new Platform(100,100,50,50));
        
        World.currentWorld.addSprite(new Player(100,100));
        World.currentWorld.addSprite(new BadGuy(300,100));
    }
    
    public static void quit(){
        System.exit(0);
    }
}
 