package org.object;

public class BadGuy extends Mob{
    
    private float velocityY = 0;
    private float gravity = 400.0f;
    private float jumpHeight = 50;
    
    private int direction = 1; // 1 = right, -1 = left

    public BadGuy(float posX, float posY) {
        super(posX, posY);
        
        width = 10;
        height = 15;
    }
    
    public void update(float deltaTime){
        float moveX = 0;
        
        moveX += direction * runSpeed;
        
        velocityY += gravity * deltaTime;
         
        if(doesCollide(posX, posY + 1)){
            //
        }
        
        //DO Collisions
        if(doesCollide(posX + moveX * deltaTime, posY )){
            moveX -= moveX;
            direction = -direction;
        }
        
        if(doesCollide(posX, posY + velocityY * deltaTime)){
            velocityY -= velocityY;
        }
        //END COLLISIONS
        
        posX += moveX * deltaTime;
        posY += velocityY * deltaTime;
    }
    
}
