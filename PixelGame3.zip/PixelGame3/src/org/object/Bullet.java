package org.object;

import java.awt.Color;
import java.awt.Graphics;
import java.io.IOException;
import java.util.logging.Level;
import java.util.logging.Logger;
import org.graphics.Animation;
import org.graphics.Renderer;

public class Bullet extends Sprite{

    public int direction = 0; // 0 = esquerda(left), 1 = direita(right);
    public float speed = 400.0f;
    public float damage = 10.0f;
    
    public Bullet(float posX, float posY, int direction) {
        super(posX, posY);
        this.direction = direction;
        width = 10;
        height = 10;
        
        isSolid = false;
        
        Animation anim = new Animation();
        try {
            anim.images.add(Renderer.loadImage("/resources/images/bullet_0.png"));
            anim.images.add(Renderer.loadImage("/resources/images/bullet_1.png"));
        } catch (IOException ex) {
            Logger.getLogger(Bullet.class.getName()).log(Level.SEVERE, null, ex);
        }
        animations = new Animation[]{
            anim
        };
    }
    
    public void update(float deltaTime){
        float moveX = 0;
        if(direction == 0){
            moveX -= speed;
        }else{
            moveX += speed;
        }
        
        posX += moveX * deltaTime;
    }
    
}
