package org.object;

public class Mob extends Sprite{
    
    protected float runSpeed = 50.0f;
    
    public Mob(float posX, float posY) {
        super(posX, posY);
    }
    
    
}
